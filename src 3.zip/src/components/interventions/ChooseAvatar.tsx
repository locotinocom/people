import { useRef, useState } from "react"
import { Swiper, SwiperSlide } from "swiper/react"
import type { Swiper as SwiperType } from "swiper"


const EVA_TEMPLATE_ID = "645cd15df23d0562d3f9d283"
const TIM_TEMPLATE_ID = "645cd12cf23d0562d3f9d27f"

const EVA_ID = "eva-dummy-123"
const TIM_ID = "tim-dummy-456"

const MOCK_MODE = import.meta.env.VITE_MOCK_MODE === "true"
console.info("Mock Mode:", MOCK_MODE ? "ON (Dummy Avatars)" : "OFF (Real API)")

type Props = { onComplete: (avatarId: string) => void }

export default function ChooseAvatar({ onComplete }: Props) {
  const [loading, setLoading] = useState(false)
  const [selected, setSelected] = useState<{
    id: string
    name: string
    img: string
    desc: string
  } | null>(null)

  const swiperRef = useRef<SwiperType | null>(null)

  // --- Echte Avatar-Erstellung ---
  const createPermanentFromTemplate = async (templateId: string) => {
    setLoading(true)

    const userRes = await fetch(
      `https://${import.meta.env.VITE_RPM_APP_SUBDOMAIN}.readyplayer.me/api/users`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          data: { applicationId: import.meta.env.VITE_RPM_APP_ID },
        }),
      }
    )
    const userData = await userRes.json()
    const token = userData.data.token

    const draftRes = await fetch(
      `https://api.readyplayer.me/v2/avatars/templates/${templateId}`,
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "X-APP-ID": import.meta.env.VITE_RPM_APP_ID,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          data: {
            partner: import.meta.env.VITE_RPM_APP_SUBDOMAIN,
            bodyType: "fullbody",
          },
        }),
      }
    )
    const draftData = await draftRes.json()
    const draftId = draftData.data.id

    const permRes = await fetch(`https://api.readyplayer.me/v2/avatars/${draftId}`, {
      method: "PUT",
      headers: {
        Authorization: `Bearer ${token}`,
        "X-APP-ID": import.meta.env.VITE_RPM_APP_ID,
      },
    })
    const permData = await permRes.json()
    const permanentId = permData.data.id

    setLoading(false)
    return permanentId
  }

  // --- Handle Auswahl ---
  const handleChoose = async (
    templateOrDummyId: string,
    name: string,
    img: string,
    desc: string
  ) => {
    try {
      let avatarId: string

      if (MOCK_MODE) {
        // Dummy-Daten für Tests
        avatarId = templateOrDummyId
      } else {
        // echter API-Call
        avatarId = await createPermanentFromTemplate(templateOrDummyId)
      }

      localStorage.setItem("avatarId", avatarId)
      setSelected({ id: avatarId, name, img, desc })

      // automatisch zum Bestätigungs-Slide
      swiperRef.current?.slideNext()
    } catch (err) {
      console.error("Avatar error:", err)
      setLoading(false)
    }
  }

  return (
    <Swiper onSwiper={(swiper) => (swiperRef.current = swiper)} allowTouchMove>
      {/* Auswahl */}
      <SwiperSlide>
        {loading && !MOCK_MODE ? (
          <div className="p-6 text-center">Avatar wird erstellt…</div>
        ) : (
          <div className="flex flex-col items-center gap-6 p-6">
            <h2 className="text-xl font-bold">Wähle deinen Begleiter</h2>

            <div className="flex justify-center gap-12">
              {/* Eva */}
              <button
                onClick={() =>
                  handleChoose(
                    MOCK_MODE ? EVA_ID : EVA_TEMPLATE_ID,
                    "Eva",
                    "/src/assets/avatars/eva.png",
                    "Streng, beherzt, tritt dir in den Hintern 🔥"
                  )
                }
                className="flex flex-col items-center p-4 bg-zinc-800 rounded-lg hover:bg-zinc-700 w-48"
              >
                <img
                  src="/src/assets/avatars/eva.png"
                  alt="Eva"
                  className="max-h-[150px] w-auto object-contain"
                />
                <p className="mt-2 font-semibold">Eva</p>
                <p className="text-xs text-gray-400 text-center">
                  Streng, beherzt, tritt dir in den Hintern 🔥
                </p>
              </button>

              {/* Tim */}
              <button
                onClick={() =>
                  handleChoose(
                    MOCK_MODE ? TIM_ID : TIM_TEMPLATE_ID,
                    "Tim",
                    "/src/assets/avatars/tim.png",
                    "Zarter Fels in der Brandung 🪨 – sanft & verständnisvoll"
                  )
                }
                className="flex flex-col items-center p-4 bg-zinc-800 rounded-lg hover:bg-zinc-700 w-48"
              >
                <img
                  src="/src/assets/avatars/tim.png"
                  alt="Tim"
                  className="max-h-[150px] w-auto object-contain"
                />
                <p className="mt-2 font-semibold">Tim</p>
                <p className="text-xs text-gray-400 text-center">
                  Zarter Fels in der Brandung 🪨 – sanft & verständnisvoll
                </p>
              </button>
            </div>
          </div>
        )}
      </SwiperSlide>

      {/* Bestätigungs-Slide */}
      <SwiperSlide>
        {selected ? (
          <div className="flex flex-col items-center p-6">
            <h2 className="text-xl font-bold">
              🎉 Cool, du hast dich für {selected.name} entschieden!
            </h2>
            <img
              src={selected.img}
              alt={selected.name}
              className="mt-6 max-h-[200px] w-auto object-contain"
            />
            <p className="mt-4 text-gray-300 text-center max-w-xs">{selected.desc}</p>
            <button
              onClick={() => onComplete(selected.id)}
              className="mt-6 px-6 py-2 bg-green-600 rounded-lg hover:bg-green-500"
            >
              Weiter
            </button>
          </div>
        ) : (
          <div className="flex items-center justify-center h-full">
            <p className="text-gray-400">Bitte zuerst einen Avatar auswählen</p>
          </div>
        )}
      </SwiperSlide>
    </Swiper>
  )
}
