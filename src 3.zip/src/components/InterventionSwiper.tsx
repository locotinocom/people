import { useRef, useState } from "react"
import { Swiper, SwiperSlide } from "swiper/react"
import type { Swiper as SwiperType } from "swiper"
import { useGame } from "../context/GameContext"
import type { RefObject } from "react"
import interventionsData from "../data/interventions.json"
import type { Intervention } from "../types/intervention"
import MultiStep from "./interventions/MultiStep"

// 🪄 Dynamisch alle Intervention-Komponenten laden
const modules = import.meta.glob("./interventions/*.tsx", { eager: true })
const componentMap: Record<string, React.ComponentType<any>> = {}

for (const path in modules) {
  const mod: any = modules[path]
  const name = path.split("/").pop()?.replace(".tsx", "") || ""
  if (mod?.default) {
    componentMap[name] = mod.default
  }
}

type Props = {
  spawnXp: (amount: number, durationOverride?: number) => Promise<void> | void
  xpTargetRef: RefObject<HTMLDivElement | null>
  diaTargetRef: RefObject<HTMLDivElement | null>
}

type Pending = { id: string | number; vIndex: number } | null

export default function InterventionSwiper({ spawnXp }: Props) {
  const { level, grantReward, markInterventionDone, completedInterventions } = useGame()
  const interventions: Intervention[] = interventionsData as Intervention[]

  const [pending, setPending] = useState<Pending>(null)
  const swiperRef = useRef<SwiperType | null>(null)

  // Nur aktuelle Level-Interventionen anzeigen
  const verticalList = interventions
    .filter(
      (i) =>
        i.level === level &&
        (!completedInterventions.includes(i.id) || pending?.id === i.id)
    )
    .sort((a, b) => a.order - b.order)

  // ✅ Abschluss einer Intervention
  const completeIntervention = (intervention: Intervention, vIndex: number, xp?: number) => {
    let totalMs = 0

    if (xp && xp > 0) {
      const count = Math.min(Math.max(1, Math.floor(xp)), 200)
      totalMs = (count - 1) * 50 + 1200
      spawnXp(xp, totalMs)
      grantReward({ type: "xp", amount: xp, meta: { duration: totalMs } })
    }

    // Pending setzen, aber noch nicht löschen
    setPending({ id: intervention.id, vIndex })

    const goNext = () => swiperRef.current?.slideNext()
    totalMs > 0 ? setTimeout(goNext, totalMs) : goNext()
  }

  // ✅ Einzelintervention rendern
  const renderSingle = (intervention: Intervention, vIdx: number) => {
    const props = {
      ...intervention.props,
      title: intervention.title,
      xp: intervention.xp,
      onComplete: () =>
        completeIntervention(intervention, vIdx, intervention.xp as number | undefined),
    }

    const Component = componentMap[intervention.template]
    if (!Component) {
      return (
        <div className="text-gray-400">
          ❌ Unbekanntes Template: {intervention.template}
        </div>
      )
    }
    return <Component {...props} />
  }

  return (
    <Swiper
      direction="vertical"
      slidesPerView={1}
      className="h-full w-full"
      onSwiper={(s) => (swiperRef.current = s)}
      onSlideChange={(s) => {
        if (pending && s.activeIndex !== pending.vIndex) {
          const doneId = pending.id
          setPending(null)

          // ✅ erst nach kurzem Delay Intervention entfernen,
          // damit Swiper stabil bleibt
          setTimeout(() => {
            markInterventionDone(doneId)
          }, 200)
        }
      }}
    >
      {verticalList.map((intervention, vIdx) => {
        const type = intervention.type ?? "single"

        return (
          <SwiperSlide key={String(intervention.id)}>
            {intervention.template === "MultiStep" || type !== "single" ? (
              <div className="h-full">
                <MultiStep
                  slides={intervention.props?.slides ?? []}
                  successXp={intervention.xp ?? 20}
                  onAllDone={() =>
                    completeIntervention(intervention, vIdx, intervention.xp ?? 20)
                  }
                />
              </div>
            ) : (
              <div className="flex items-center justify-center h-full bg-zinc-800">
                {renderSingle(intervention, vIdx)}
              </div>
            )}
          </SwiperSlide>
        )
      })}
    </Swiper>
  )
}
