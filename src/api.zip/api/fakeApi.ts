import interventionsData from "../data/interventions.json"
import type { ApiInterface, GameState, ApiGameStateResponse, Intervention, Reward, StepProgress, User } from "./types"

const delay = (ms: number) => new Promise((r) => setTimeout(r, ms))

export const fakeApi = {
  async getUser(): Promise<User> {
    await delay(100)
    return {
      id: 1,
      name: localStorage.getItem("avatarName") || "Tim",
      avatarId: localStorage.getItem("avatarId") || "tim-dummy",
      level: Number(localStorage.getItem("level")) || 1,
      xp: Number(localStorage.getItem("xp")) || 0,
      rewards: JSON.parse(localStorage.getItem("rewards") || "[]"),
      data: JSON.parse(localStorage.getItem("data") || "{}"),
    }
  },

  async setAvatar(name: string | null, avatarId: string | null) {
    const prevName = localStorage.getItem("avatarName")
    const prevId = localStorage.getItem("avatarId")
    if (prevName === name && prevId === avatarId) return { success: false }

    if (name === null) {
      localStorage.removeItem("avatarName")
    } else {
      localStorage.setItem("avatarName", name)
    }

    if (avatarId === null) {
      localStorage.removeItem("avatarId")
    } else {
      localStorage.setItem("avatarId", avatarId)
    }

    return { success: true }
  },

  async getFullGameState(): Promise<ApiGameStateResponse> {
    await delay(100)
    const raw = localStorage.getItem("gameState")
    let data: GameState
    if (!raw) {
      data = {
        level: 1,
        xp: 0,
        dias: 0,
        completedInterventions: [],
        avatarId: null,
        avatarName: null,
        answers: {},
      }
    } else {
      data = JSON.parse(raw)
    }
    return { success: true, data }
  },

  async saveGameState(data: any) {
    await delay(100)
    localStorage.setItem("gameState", JSON.stringify(data))
    return { success: true }
  },

  async getInterventions(level: any) {
    await delay(100)
    const data = (interventionsData as Record<string, any[]>)[String(level)] ?? []
    return data.map((item, i) => ({ ...item, id: i + 1, order: i + 1, level }))
  },

  async updateProgress(interventionId: any, xp: any) {
    await delay(100)
    const state = JSON.parse(localStorage.getItem("gameState") || "{}") || {}
    const completed = state.completedInterventions || []
    if (!completed.includes(interventionId)) completed.push(interventionId)
    state.completedInterventions = completed
    state.xp = (state.xp || 0) + xp
    localStorage.setItem("gameState", JSON.stringify(state))
    return { success: true, xp: state.xp }
  },

  async getRewards(): Promise<Reward[]> {
    await delay(100)
    return JSON.parse(localStorage.getItem("rewards") || "[]")
  },

  async grantDiamonds(amount: number) {
    const state = JSON.parse(localStorage.getItem("gameState") || "{}") || {}
    state.dias = (state.dias || 0) + amount
    localStorage.setItem("gameState", JSON.stringify(state))
    return { success: true, dias: state.dias }
  },

  async getCurrentStep(): Promise<StepProgress> {
    const idx = Number(localStorage.getItem("currentStep") || "0")
    return { stepIndex: idx }
  },

  async updateCurrentStep(stepIndex: number) {
    localStorage.setItem("currentStep", String(stepIndex))
    return { success: true }
  },

  async resetProgress(): Promise<{ success: boolean }> {
    localStorage.removeItem("currentStep")
    return { success: true }
  },
} as unknown as ApiInterface
