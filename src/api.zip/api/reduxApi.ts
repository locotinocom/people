import useAuthHeader from "react-auth-kit/hooks/useAuthHeader"
import { createBaseApi } from "./reduxApiBase"

export function useReduxApi() {
  const header = useAuthHeader()
console.log("Auth Header:", header)
  return createBaseApi(() => header ?? undefined)
}
