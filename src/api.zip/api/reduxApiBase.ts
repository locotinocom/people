import { request } from "./request"

export function createBaseApi(getAuthHeader: () => string | undefined) {
  return {
    getUser() {
      return request("/user", {}, getAuthHeader())
    },

    setAvatar(name: string, avatar_id: number) {
      return request(
        "/avatars/setAvatar",
        {
          method: "POST",
          body: JSON.stringify({ name, avatar_id }),
        },
        getAuthHeader()
      )
    },

    getFullGameState() {
      return request("/game/state", { method: "GET" }, getAuthHeader())
    },

    getProgress() {
      return request("/game/get-progress", { method: "GET" }, getAuthHeader())
    },

    saveGameState(data: any) {
      return request(
        "/game/saveGamestate",
        {
          method: "POST",
          body: JSON.stringify(data),
        },
        getAuthHeader()
      )
    },

    getInterventions(level: number) {
      return request(`/game/interventions?level=${level}`, {}, getAuthHeader())
    },

    saveInterventionProgress(interventionId: number, xp: number) {
      return request(
        "/game/saveInterventionProgress",
        {
          method: "POST",
          body: JSON.stringify({ interventionId, xp }),
        },
        getAuthHeader()
      )
    },

    getCurrentStep() {
      return request("/progress/current", {}, getAuthHeader())
    },

    getCurrentLevel() {
      return request("/game/getCurrentLevel", { method: "GET" }, getAuthHeader())
    },

    updateCurrentStep(interventionId: number) {
      return request(
        "/game/updateprogress",
        {
          method: "POST",
          body: JSON.stringify({ interventionId }),
        },
        getAuthHeader()
      )
    },

    getRewards() {
      return request("/rewards", {}, getAuthHeader())
    },

    resetProgress() {
      return request("/progress/reset", { method: "POST" }, getAuthHeader())
    },
  }
}
