// src/api/adminApi.ts
import { request } from './request'

export type AdminUser = {
  id: number
  email: string
  name: string
  role: string
  is_verified: boolean
  provider?: string
  created?: string
  modified?: string
}

export type ApiResponse<T> = {
  success: boolean
  data: T
  message?: string
  error?: string | null
}

export const adminApi = {
  /** GET /admin/users */
  getUsers(token?: string): Promise<ApiResponse<AdminUser[]>> {
    return request('/admin/users', {}, token)
  },

  /** POST /admin/interventionsUpload */
  uploadInterventions(
    formData: FormData,
    token?: string
  ): Promise<ApiResponse<{ updated: number }>> {
    return request('/admin/interventionsUpload', { method: 'POST', body: formData }, token)
  },

  /** POST /admin/updateMaster */
  updateMaster(token?: string): Promise<ApiResponse<{ updated: number }>> {
    return request('/admin/updateMaster', { method: 'POST' }, token)
  },

  /** DELETE /admin/userDelete/{id} */
  deleteUser(id: number, token?: string): Promise<ApiResponse<null>> {
    return request(`/admin/userDelete/${id}`, { method: 'DELETE' }, token)
  },
}
