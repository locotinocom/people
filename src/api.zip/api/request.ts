import { useCallback } from "react"
import useAuthHeader from "react-auth-kit/hooks/useAuthHeader"
import toast from "react-hot-toast"
import type { ApiResponse } from "@api/types"   // <-- wichtig: dein gemeinsamer Typ

export function useRequest() {
  const authHeader = useAuthHeader() // string | null

  const request = useCallback(
    async <T>(endpoint: string, options: RequestInit = {}): Promise<T> => {
      const url = `${import.meta.env.VITE_API_URL}${endpoint}`

      try {
        const res = await fetch(url, {
          ...options,
          headers: {
            "Content-Type": "application/json",
            ...(authHeader ? { Authorization: authHeader } : {}),
            ...(options.headers || {}),
          },
        })

        const text = await res.text()
        let json: ApiResponse<T>

        // -------------------------
        // JSON PARSEN
        // -------------------------
        try {
          json = text ? JSON.parse(text) : {}
        } catch {
          toast.error("Ungültige JSON-Antwort vom Server.")
          throw new Error("INVALID_JSON")
        }

        // -------------------------
        // FEHLERPRÜFUNG
        // -------------------------
        if (!res.ok || json.success === false) {
          const status = res.status
          const message =
            json.error ||
            json.message ||
            "Unbekannter Fehler"

          toast.error(`${message} (Fehler ${status})`)
          throw new Error(JSON.stringify({ status, message }))
        }

        // -------------------------
        // ERFOLG: data zurückgeben
        // -------------------------
        return (json.data as T)
      } catch (err) {
        toast.error("Verbindungsfehler zur API")
        throw err
      }
    },
    [authHeader]
  )

  return request
}
