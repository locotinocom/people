// 👤 Benutzer-Datenstruktur
export interface User {
  id: number
  name: string
  avatarId: string
  level: number
  xp: number
  rewards: Reward[]
  data: Record<string, any>
}

// 🎁 Belohnung
export interface Reward {
  id?: number
  name?: string
  type?: string
  description?: string
  unlocked?: boolean
}

// 💬 Intervention
export interface Intervention {
  id: number
  title: string
  template: string
  type?: "single" | "multi"
  level: number
  order: number
  xp?: number
  skippable?: boolean
  props?: Record<string, any>
}

export type GetProgressResponse = { intervention_id: number } | null

// 🪜 Fortschritt innerhalb einer Intervention
export interface StepProgress {
  stepIndex: number
}

// 🧠 Spielzustand auf Client-Seite (lokal)
export interface GameState {
  level: number
  xp: number
  dias: number
  completedInterventions: number[]
  avatarId: string | null
  avatarName: string | null
  answers: Record<string, string | number | boolean>
}

// 📊 Fortschritt auf Server-Seite (persistiert)
export interface Progress {
  id: number
  user_id: number
  current_level: number
  current_intervention_id: number | null
  diamonds: number
  xp_total: number
  tools: string[]
  equipment: string[]
  last_access: string
}

// 🎮 Kombinierter Spielzustand (Server-Response)
export interface GameStateBundle {
  user?: Record<string, any>
  data?: Record<string, any>
  progress?: any
  interventions?: any
  rewards?: any
}

// 🌐 Gemeinsamer API-Response-Typ für ALLE Endpunkte
export interface ApiResponse<T = any> {
  success: boolean
  message?: string
  error?: string | null
  data?: T
}

// 🌐 API-Schnittstelle
export interface ApiInterface {
  getUser: () => Promise<ApiResponse<User>>
  setAvatar: (name: string, avatarId: string) => Promise<ApiResponse<{ success: boolean }>>
  getFullGameState: () => Promise<ApiResponse<GameStateBundle>>
  saveGameState: (data: Record<string, any>) => Promise<ApiResponse<{ success: boolean }>>
  getInterventions: (level: number) => Promise<ApiResponse<Intervention[]>>
  saveInterventionProgress: (interventionId: number, xp: number) => Promise<ApiResponse<{ success: boolean; xp?: number }>>
  getCurrentStep: () => Promise<ApiResponse<StepProgress>>
  updateCurrentStep: (interventionId: number) => Promise<ApiResponse<{ success: boolean }>>
  getRewards: () => Promise<ApiResponse<Reward[]>>
  resetProgress: () => Promise<ApiResponse<{ success: boolean }>>
  getProgress: () => Promise<ApiResponse<GetProgressResponse>>
  getCurrentLevel: () => Promise<ApiResponse<Record<string, any>>>
}

// 🌐 Extra-Argument für Redux-Thunks
export interface ThunkExtraArgument {
  api: {
    getFullGameState: () => Promise<ApiResponse<GameStateBundle>>
    getProgress?: () => Promise<ApiResponse<GetProgressResponse>>
  }
}
