import { Swiper, SwiperSlide } from "swiper/react"
import { useData } from "@context/DataContext"
import SingleSlide from "./SingleSlide"
import MultiSlide from "./MultiSlide"
import { useGameState } from "@context/GameStateContext"

// -----------------------------------------------------------------------------
// Typen
// -----------------------------------------------------------------------------
type RawIntervention = {
  id: number
  type?: "single" | "multi"
  template?: string
  props?: string | Record<string, any> | null
  slides?: string | any[] | null
}

type ParsedSlide = { template: string; props?: Record<string, any> }

type ParsedIntervention = {
  id: number
  type: "single" | "multi"
  template: string
  props: Record<string, any>
  slides: ParsedSlide[]
}

// -----------------------------------------------------------------------------
// Templates dynamisch importieren
// -----------------------------------------------------------------------------
const modules = import.meta.glob("../interventions/*.tsx", { eager: true })
const componentMap: Record<string, React.ComponentType<{ data: any }>> = {}

for (const path in modules) {
  const mod = modules[path] as { default?: React.ComponentType<{ data: any }> }
  const name = path.split("/").pop()?.replace(".tsx", "") ?? ""
  if (mod.default) componentMap[name] = mod.default
}

// -----------------------------------------------------------------------------
// JSON-Parser
// -----------------------------------------------------------------------------
function safeJsonParse<T>(value: unknown, fallback: T): T {
  if (!value) return fallback
  if (typeof value === "object") return value as T
  if (typeof value === "string" && value.trim() === "") return fallback
  try {
    return JSON.parse(value as string) as T
  } catch {
    return fallback
  }
}

// -----------------------------------------------------------------------------
// Hauptkomponente
// -----------------------------------------------------------------------------
export default function Gameplay() {
  const { interventions, isLoading } = useData()
  const { currentInterventionId } = useGameState()

  if (isLoading) return <div className="p-6 text-zinc-400">Lade…</div>
  if (!interventions?.length) return <div className="p-6 text-zinc-400">Keine Daten.</div>

  // 🔹 JSON-Daten sicher in echte Objekte umwandeln
  const parsedInterventions: ParsedIntervention[] = interventions.map(
    (raw: RawIntervention): ParsedIntervention => ({
      id: raw.id,
      type: raw.type ?? "single",
      template: raw.template ?? "Info",
      props: safeJsonParse<Record<string, any>>(raw.props, {}),
      slides: safeJsonParse<ParsedSlide[]>(raw.slides, []),
    })
  )

  // 👉 Index des zuletzt bearbeiteten Eintrags
  const startIndex = parsedInterventions.findIndex(
    (i) => i.id === currentInterventionId
  )
  console.log("🎯 Startindex:", startIndex, "für Intervention ID:", currentInterventionId)

  // 🔹 EIN vertikaler Swiper für alles
  return (
    <Swiper
      className="h-full w-full flex-1 bg-zinc-900 overflow-hidden"
      direction="vertical"
      slidesPerView={1}
      nested
      observer
      observeParents
      watchSlidesProgress
      updateOnWindowResize={false}
      initialSlide={startIndex >= 0 ? startIndex : 0} // 🔹 Hier der Sprung

    >
      {parsedInterventions.map((intervention) => {
        const { id, type, template, props, slides } = intervention
        const Template = componentMap[template]

        if (!Template)
          return (
            <SwiperSlide key={id}>
              <div className="text-zinc-400 p-6">Kein Template gefunden: {template}</div>
            </SwiperSlide>
          )

        // SINGLE → direkt als vertikale Slide
        if (type === "single") {
          console.log("➡️ Rendering SingleSlide:", { id, template, props })
          return (
            <SwiperSlide key={id} className="!h-full flex items-center justify-center">
              <SingleSlide id={id}>
                <Template data={{ ...props, id, type, template }} />
              </SingleSlide>
            </SwiperSlide>
          )
        }

        // MULTI → verschachtelter horizontaler Swiper
  if (type === "multi") {
    // Slides kommen direkt aus props (nicht aus componentMap)
    const slideList = Array.isArray(slides)
      ? slides
      : Array.isArray(props.slides)
      ? props.slides
      : []

    // Jede Slide hat ihr eigenes Template
    const slideContents = slideList.map((s, i) => {
      const T = componentMap[s.template]
      if (!T)
        return (
          <div key={i} className="p-6 text-zinc-400">
            Kein Template gefunden: {s.template}
          </div>
        )
      const p = safeJsonParse<Record<string, any>>(s.props, {})
      return <T key={i} data={{ ...p, parentId: id }} />
    })

    return (
      <SwiperSlide key={id} className="!h-full">
        <MultiSlide id={id} slides={slideContents} />
      </SwiperSlide>
    )
  }


        return null
      })}
    </Swiper>
  )
}
