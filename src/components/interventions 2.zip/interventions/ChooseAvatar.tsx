import { useState } from "react"
import { useCreatePermanentAvatar } from "@hooks/useCreatePermanentAvatar"

// Redux
import { useAppDispatch } from "@store/hooks"
import {
  completeInterventionThunk,
  handleActionThunk,
} from "@store/slices/gameActionsSlice"

// API
import { useReduxApi } from "@api/reduxApi"

// Slide-Manager
import { useSlideManager } from "@context/SlideManagerContext"

// Avatare
import { LOCAL_AVATARS } from "@data/avatars"

// Avatar Render
import AvatarRender from "@components/AvatarRender"

type ChooseAvatarData = {
  id: number
  xp: number
  title?: string
  subtitle?: string
  avatars?: any[]
}

export default function ChooseAvatar({ data }: { data: ChooseAvatarData }) {
  const dispatch = useAppDispatch()
  const api = useReduxApi()
  const slideManager = useSlideManager()

  const { createPermanentAvatar } = useCreatePermanentAvatar()

  const [selected, setSelected] = useState<any>(null)
  const [saving, setSaving] = useState(false)
  const [step, setStep] = useState<"select" | "creating" | "confirm">("select")
  const [permanentAvatarId, setPermanentAvatarId] = useState<string | null>(null)

  if (!data) {
    return <div className="text-red-400 p-6">Fehler: Keine Daten übergeben.</div>
  }

  const avatarList =
    Array.isArray(data.avatars) && data.avatars.length > 0
      ? data.avatars
      : LOCAL_AVATARS

  // ----------------------------------------------------
  // NUR Auswahl markieren – nicht bestätigen!
  // ----------------------------------------------------
  const handleSelect = (avatar: any) => {
    setSelected(avatar)
  }

  // ----------------------------------------------------
  // NUR wenn er "Auswahl bestätigen" klickt → Avatar erzeugen
  // ----------------------------------------------------
  const handleConfirm = async () => {
    if (!selected) return

    setStep("creating")

    const id = await createPermanentAvatar(String(selected.templateId))
    if (id) {
      setPermanentAvatarId(id)
      setStep("confirm")
    }
  }

  // ----------------------------------------------------
  // FINAL SPEICHERN
  // ----------------------------------------------------
  const handleSave = async () => {
    if (!api || saving) return
    if (!permanentAvatarId) return

    setSaving(true)

    const res = await api.setAvatar(selected.name, permanentAvatarId,selected.gender)
    if (!res.success) {
      console.error("Avatar speichern fehlgeschlagen")
      setSaving(false)
      return
    }

    await dispatch(
      completeInterventionThunk({
        interventionId: data.id,
        xp: data.xp,
        api,
        playAnimation: () => {},
      })
    )

    await dispatch(
      handleActionThunk({
        action: { type: "next", goNext: () => slideManager.goNext() },
        api,
        playAnimation: () => {},
      })
    )

    setSaving(false)
  }

  // ---------------------------------------------------------------------------
  // STEP A – Avatar auswählen
  // ---------------------------------------------------------------------------
  if (step === "select") {
    return (
      <div className="flex flex-col items-center text-center p-6 h-full text-white">
        <h2 className="text-2xl font-bold mb-2">
          {data.title || "Wähle deinen Avatar"}
        </h2>

        {data.subtitle && (
          <p className="mb-6 text-sm text-gray-300 max-w-xs">{data.subtitle}</p>
        )}

        <div className="grid grid-cols-2 gap-6 mb-8">
          {avatarList.map((avatar) => (
            <button
              key={avatar.id}
              onClick={() => handleSelect(avatar)}
              className={`flex flex-col items-center p-3 rounded-xl border transition ${
                selected?.id === avatar.id
                  ? "border-blue-400 scale-105"
                  : "border-gray-600 hover:border-gray-400"
              }`}
            >
              <img
                src={avatar.image}
                className="w-28 h-28 rounded-full object-cover mb-2"
              />

              <span className="text-sm font-medium">{avatar.name}</span>

              {avatar.description && (
                <span className="text-xs text-gray-300 mt-2 text-center max-w-[140px]">
                  {avatar.description}
                </span>
              )}
            </button>
          ))}
        </div>

        <button
          onClick={handleConfirm}
          disabled={!selected}
          className={`px-6 py-3 rounded-lg font-bold ${
            selected
              ? "bg-green-600 hover:bg-green-500"
              : "bg-gray-600 cursor-not-allowed"
          }`}
        >
          Auswahl bestätigen
        </button>
      </div>
    )
  }

  // ---------------------------------------------------------------------------
  // STEP B – Avatar wird erzeugt
  // ---------------------------------------------------------------------------
  if (step === "creating") {
    return (
      <div className="absolute inset-0 flex items-center justify-center bg-black/70 text-white text-2xl font-bold">
        Erstelle deinen Begleiter…
      </div>
    )
  }

  // ---------------------------------------------------------------------------
  // STEP C – Avatar bestätigt
  // ---------------------------------------------------------------------------
  return (
    <div className="flex flex-col items-center text-center p-6 h-full text-white">
      <h2 className="text-2xl font-bold mb-4">
        Cool, du hast dich für{" "}
        <span className="text-blue-300">{selected.name}</span> entschieden!
      </h2>

      <div className="w-40 h-40 mb-6">
        <AvatarRender
          name={selected.name.toLowerCase()}
          emotion="happy"
          pose="thumbs-up"
          camera="portrait"
        />
      </div>

      <button
        onClick={handleSave}
        disabled={saving}
        className="px-6 py-3 bg-green-600 rounded-lg font-bold hover:bg-green-500"
      >
        {saving ? "Speichere…" : "Weiter"}
      </button>
    </div>
  )
}
