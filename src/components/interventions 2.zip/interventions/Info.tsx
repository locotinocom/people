type InfoData = {
  title?: string
  message?: string
  onComplete?: () => void
}

import { applyTemplate } from "@helpers/template"
import SwipeHint from "@components/SwipeHint"
import { useAppSelector } from "@store/hooks"

export default function Info({ data }: { data: InfoData }) {
  const { title = "", message = "", onComplete } = data

  // Level aus Redux holen
  const level = useAppSelector((s) => s.game.level)

  // Avatar-Name für Template
  const rawName = localStorage.getItem("avatarName") || ""
  const rendered = applyTemplate(message, { avatarName: rawName })

  return (
    <div
      className="relative flex flex-col items-center justify-center h-full p-8 text-center"
      onClick={onComplete}
    >
      {title && <h2 className="text-2xl font-bold mb-4">{title}</h2>}
      {rendered && (
        <p className="text-lg text-gray-200 whitespace-pre-line">{rendered}</p>
      )}

      {/* 🔥 Nur wenn Level == 1 */}
      {level === 1 && <SwipeHint />}
    </div>
  )
}
