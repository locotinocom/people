import AvatarRender from "../AvatarRender"
import { useRef } from "react"

// API
import { useReduxApi } from "@api/reduxApi"

// Redux
import { useAppDispatch } from "@store/hooks"
import {
  completeInterventionThunk,
  handleActionThunk,
} from "@store/slices/gameActionsSlice"

// SlideManager
import { useSlideManager } from "@context/SlideManagerContext"

// AnimationContext
import { useAnimation } from "@context/AnimationContext"

type SimpleActionData = {
  id: number
  title?: string
  message?: string
  buttonText?: string
  xp?: number
  camera?: "portrait" | "fullbody" | "head"
}

export default function SimpleAction({ data }: { data: SimpleActionData }) {
  const { id, title, message, buttonText, xp = 5, camera = "fullbody" } = data

  const dispatch = useAppDispatch()
  const api = useReduxApi()
  const slideManager = useSlideManager()

  // AnimationContext
  const { start: startAnimation } = useAnimation()

  const rawName = localStorage.getItem("avatarName") || "dein Begleiter"
  const avatarName = rawName.charAt(0).toUpperCase() + rawName.slice(1)
  const btnRef = useRef<HTMLButtonElement | null>(null)

  const handleComplete = async () => {
    if (!api) return

    console.log("📌 SimpleAction:", { id, xp })

    // 1) XP-Animation starten (vom Button losfliegend)
    if (xp > 0) {
      startAnimation("xp", {
        from: btnRef.current,
      })
    }

    // 2) Fortschritt speichern
    await dispatch(
      completeInterventionThunk({
        interventionId: id,
        xp,
        api,
        playAnimation: startAnimation, // ← Thunk kann Animation auch nutzen
      })
    )

    console.log("🎉 SimpleAction abgeschlossen", { id })

    // 3) UX-Delay
    await new Promise((resolve) => setTimeout(resolve, 400))

    // 4) weiter
    await dispatch(
      handleActionThunk({
        action: {
          type: "next",
          goNext: () => slideManager.goNext(),
        },
        playAnimation: startAnimation, // ← Weitergabe an Thunk
        api,
      })
    )
  }

  return (
    <div className="flex h-full p-10">
      <div className="w-45 flex items-center justify-center">
        <AvatarRender
          name={rawName}
          emotion="happy"
          pose="relaxed"
          camera={camera}
        />
      </div>

      <div className="flex flex-col max-w-md mt-10 space-y-6 pt-12">
        {title && <h2 className="text-2xl font-bold text-white">{title}</h2>}

        {message && (
          <p className="text-gray-300 whitespace-pre-line p-5">
            {message.replace(/\{\{avatarName\}\}/g, avatarName)}
          </p>
        )}

        <button
          ref={btnRef}
          onClick={handleComplete}
          className="px-6 py-3 bg-green-600 hover:bg-green-500 rounded-lg font-bold text-white"
        >
          {buttonText ?? "Weiter"}
        </button>

        {xp > 0 && (
          <p className="text-sm text-gray-400 pt-1">
            Aufgabe erledigen bringt +{xp} XP
          </p>
        )}
      </div>
    </div>
  )
}
