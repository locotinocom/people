// components/inventory/LevelSection.tsx
import ItemCard from "./ItemCard"
import type { InventoryItem } from "@api/types"

type Props = {
  level: number
  items: InventoryItem[]
}

export default function LevelSection({ level, items }: Props) {
  return (
    <div>
      <p className="text-sm text-gray-400 mb-2">Level {level}</p>

      <div className="flex gap-4 overflow-x-auto no-scrollbar">
        {items.map((item) => (
          <ItemCard key={item.asset_id} item={item} />
        ))}
      </div>
    </div>
  )
}
