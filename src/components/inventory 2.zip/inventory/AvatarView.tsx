import { Canvas } from "@react-three/fiber"
import { OrbitControls, useGLTF } from "@react-three/drei"

function AvatarModel({ url }: { url: string }) {
  const { scene } = useGLTF(url)
  return <primitive object={scene} scale={1.2} />
}

export default function AvatarView({ glbUrl }: { glbUrl: string }) {
  if (!glbUrl) {
    return (
      <div className="w-full h-full flex items-center justify-center text-gray-400">
        Kein Avatar geladen
      </div>
    )
  }

  return (
    <Canvas
      className="pointer-events-none w-0.500 h-full bg-gray-900"
      style={{ marginRight:"10%", width: "90%", height: "100%", backgroundColor: "green" }}
      camera={{ position: [0, 2, 4.2], fov: 40}}
    >
      <ambientLight intensity={0.8} />
      <directionalLight position={[2, 2, 2]} />
      <AvatarModel url={glbUrl} />
      <OrbitControls target={[0, 1.2, 0]} enablePan={false} />
    </Canvas>
  )
}
