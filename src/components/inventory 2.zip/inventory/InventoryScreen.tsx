// components/inventory/InventoryScreen.tsx

import { useState, useMemo, useEffect } from "react"
import AvatarView from "./AvatarView"
import CategoryBar from "./CategoryBar"
import LevelSection from "./LevelSection"

import { useAppDispatch, useAppSelector } from "@store/hooks"
import { fetchInventory } from "@store/slices/inventorySlice"
import { useReduxApi } from "@api/reduxApi"
import type { InventoryItem } from "@api/types"

export default function InventoryScreen() {
  const dispatch = useAppDispatch()
  const api = useReduxApi()

  const [category, setCategory] = useState("hair")

  const avatarGlb = useAppSelector((s) => s.avatar.avatar?.glbUrl)
  const items = useAppSelector((s) => s.inventory.items) as InventoryItem[]

  // Inventory laden
  useEffect(() => {
    if (!api) return
    dispatch(fetchInventory(api))
  }, [api, dispatch])

  // Items nach Kategorie filtern
  const filtered = useMemo(
    () => items.filter((i) => i.type === category),
    [items, category]
  )

  // Level-Gruppierung
  const levels = useMemo(
    () =>
      [...new Set(filtered.map((i) => i.required_level))].sort(
        (a, b) => a - b
      ),
    [filtered]
  )

  return (
    <div className="w-full h-full flex flex-col bg-gray-900 text-white">

      {/* Avatar-Bereich */}
      <div className="h-[66%] border-b border-gray-800 bg-gray-900">
        {avatarGlb ? (
          <AvatarView glbUrl={avatarGlb} />
        ) : (
          <div className="flex items-center justify-center h-full text-gray-500">
            Kein Avatar geladen
          </div>
        )}
      </div>

      {/* Kategorien */}
      <CategoryBar active={category} onChange={setCategory} />

      {/* Items */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6 bg-gray-800">
        {levels.length === 0 && (
          <div className="text-sm text-gray-400">
            Keine Items in dieser Kategorie.
          </div>
        )}

        {levels.map((lvl) => (
          <LevelSection
            key={lvl}
            level={lvl}
            items={filtered.filter((i) => i.required_level === lvl)}
          />
        ))}
      </div>
    </div>
  )
}
