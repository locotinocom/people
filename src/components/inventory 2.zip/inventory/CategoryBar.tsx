// components/inventory/CategoryBar.tsx

import {
  INVENTORY_CATEGORIES,
  INVENTORY_CATEGORY_LABELS,
} from "@data/inventory"

type Props = {
  active: string
  onChange: (key: string) => void
}

export default function CategoryBar({ active, onChange }: Props) {
  return (
    <div className="w-full bg-gray-800 h-12 px-2 flex items-center select-none">

      <button className="px-2 text-xl text-gray-400 hover:text-white">&lt;</button>

      <div className="flex gap-4 overflow-x-auto no-scrollbar flex-1 px-2">
        {INVENTORY_CATEGORIES.map((key) => (
          <button
            key={key}
            onClick={() => onChange(key)}
            className={`text-sm whitespace-nowrap pb-1 ${
              active === key
                ? "text-blue-400 font-semibold border-b-2 border-blue-400"
                : "text-gray-300 hover:text-white"
            }`}
          >
            {INVENTORY_CATEGORY_LABELS[key]}
          </button>
        ))}
      </div>

      <button className="px-2 text-xl text-gray-400 hover:text-white">&gt;</button>
    </div>
  )
}
