// components/inventory/ItemCard.tsx

import { useAppDispatch, useAppSelector } from "@store/hooks"
//import { equipItem } from "@store/slices/inventorySlice"
import { reloadAvatar } from "@store/slices/avatarSlice"
import { useReduxApi } from "@api/reduxApi"
import type { InventoryItem } from "@api/types"

export default function ItemCard({ item }: { item: InventoryItem }) {
  const dispatch = useAppDispatch()
  const api = useReduxApi()
  const userLevel = useAppSelector((s) => s.game.level)

  const locked = userLevel < item.required_level
  const owned = item.owned
  const equipped = item.equipped

  const handleEquip = () => {
    if (!api) return
    if (!owned || locked) return

 /*    dispatch(
      equipItem({
        api,
        assetId: item.asset_id,
        category: item.type,
        glbReload: () => dispatch(reloadAvatar()),
      })
    ) */
  }

  return (
    <button
      onClick={handleEquip}
      className={`relative flex flex-col items-center min-w-[90px] ${
        locked ? "opacity-30" : ""
      }`}
    >
      <img
        src={item.icon_url}
        className="w-20 h-20 object-contain rounded-lg border border-gray-700 bg-black/40"
      />

      {equipped && (
        <span className="absolute top-1 right-1 text-xs bg-blue-600 px-1 rounded shadow">
          ✓
        </span>
      )}

      {!owned && !locked && (
        <span className="absolute bottom-1 text-xs bg-purple-700 px-2 rounded shadow">
          {item.price_dias} 💎
        </span>
      )}

      <p className="text-xs mt-1 text-center">{item.name}</p>
    </button>
  )
}
