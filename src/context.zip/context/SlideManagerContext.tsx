import { createContext, useContext, useRef } from "react"
import type { Swiper as SwiperType } from "swiper"

type SlideManager = {
  setSwiper: (swiper: SwiperType) => void
  goNext: () => void
  goPrev: () => void
}

const SlideManagerContext = createContext<SlideManager | null>(null)
export const useSlideManager = () => useContext(SlideManagerContext)!

export function SlideManagerProvider({ children }: { children: React.ReactNode }) {
  const swiperRef = useRef<SwiperType | null>(null)

  const setSwiper = (swiper: SwiperType) => {
    swiperRef.current = swiper
  }

  const goNext = () => {
    swiperRef.current?.slideNext()
  }

  const goPrev = () => {
    swiperRef.current?.slidePrev()
  }

  return (
    <SlideManagerContext.Provider value={{ setSwiper, goNext, goPrev }}>
      {children}
    </SlideManagerContext.Provider>
  )
}
