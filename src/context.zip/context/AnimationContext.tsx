import { createContext, useContext, useState, useRef, useCallback } from "react"
import type { ReactNode } from "react"
import { AnimationOverlay } from "@components/animations/AnimationOverlay"
import { FlyParticles } from "@components/animations/FlyParticles"

export type FlyConfig = {
  from?: HTMLElement | null        // Startpunkt (z. B. Button) – darf fehlen
  to?: HTMLElement | null          // Ziel (z. B. Progress-Bar)
  count?: number
  duration?: number
  size?: number
}

export type AnimationType = "xp" | "diamond" | "levelup"

type AnimationContextType = {
  start: (type: AnimationType, fly?: FlyConfig) => void
}

const AnimationContext = createContext<AnimationContextType>({ start: () => {} })
export const useAnimation = () => useContext(AnimationContext)

export function AnimationProvider({ children }: { children: ReactNode }) {
  const [active, setActive] = useState<AnimationType | null>(null)
  const [fly, setFly] = useState<
    (FlyConfig & {
      content: string
      color: string
      shapeType: "character"
    }) | null
  >(null)
  const flyKey = useRef(0)

  // visuelle definitionen pro typ
  const visuals: Record<AnimationType, { content: string; color: string }> = {
    xp: { content: "XP", color: "#22c55e" },
    diamond: { content: "💎", color: "#3b82f6" },
    levelup: { content: "↑", color: "#facc15" },
  }

  const start = useCallback(
    (type: AnimationType, flyConfig?: FlyConfig) => {
      const visual = visuals[type]

      // Standard-Ziel ist die XP-Progressbar
      const to =
        flyConfig?.to ??
        document.getElementById("Loco_ProgressBar_XP") ??
        document.body

      // 🔹 Falls kein from übergeben → Mittelpunkt des Screens als Startpunkt
      let fromEl: HTMLElement | null = flyConfig?.from ?? null
      let tempDummy: HTMLElement | null = null

      if (!fromEl) {
        const dummy = document.createElement("div")
        dummy.style.position = "fixed"
        dummy.style.left = `${window.innerWidth / 2}px`
        dummy.style.top = `${window.innerHeight / 2}px`
        dummy.style.width = "1px"
        dummy.style.height = "1px"
        dummy.style.pointerEvents = "none"
        dummy.style.opacity = "0"
        document.body.appendChild(dummy)
        fromEl = dummy
        tempDummy = dummy
      }

      // Fluganimationen
      if (type === "xp" || type === "diamond") {
        flyKey.current++
        setFly({
          from: fromEl!,
          to,
          count: flyConfig?.count ?? (type === "xp" ? 10 : 6),
          duration: flyConfig?.duration ?? (type === "xp" ? 1.4 : 1.8),
          size: flyConfig?.size ?? (type === "xp" ? 22 : 28),
          content: visual.content,
          color: visual.color,
          shapeType: "character",
        })
      }

      // Level-Up-Overlay
      if (type === "levelup") {
        setActive("levelup")
        setTimeout(() => setActive(null), 1800)
      }

      // Dummy nach kurzer Zeit entfernen
      if (tempDummy) {
        setTimeout(() => tempDummy?.remove(), 1600)
      }
    },
    [visuals]
  )

  return (
    <AnimationContext.Provider value={{ start }}>
      {children}

      {active === "levelup" && <AnimationOverlay active="levelup" />}

      {fly && (
        <FlyParticles
          key={flyKey.current}
          {...fly}
          onDone={() => setFly(null)}
        />
      )}
    </AnimationContext.Provider>
  )
}
