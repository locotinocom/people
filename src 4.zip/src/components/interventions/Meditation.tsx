import { useState, useEffect, useRef } from "react"
import { Howl, Howler } from "howler"
import { motion, useAnimation } from "framer-motion"
import { useGame } from "../../context/GameContext"

type Props = {
  title: string
  description: string
  audio: string
  background?: string
  hasBackgroundMusic?: boolean
  duration: number
  onComplete?: () => void
}

export default function Meditation({
  title,
  description,
  audio,
  background,
  hasBackgroundMusic = false,
  duration,
  onComplete,
}: Props) {
  const { avatarId } = useGame()
  const avatar = avatarId || "tim"

  const [playing, setPlaying] = useState(false)
  const [progress, setProgress] = useState(0)
  const [error, setError] = useState<string | null>(null)
  const controls = useAnimation()

  const mainRef = useRef<Howl | null>(null)
  const bgRef = useRef<Howl | null>(null)
  const startTime = useRef<number | null>(null)
  const animLocked = useRef(false)
  const endCalled = useRef(false)

  // progress-loop
  useEffect(() => {
    if (!playing) return
    let id = requestAnimationFrame(function tick() {
      if (startTime.current) {
        const elapsed = (Date.now() - startTime.current) / 1000
        setProgress(Math.min(elapsed / duration, 1))
      }
      id = requestAnimationFrame(tick)
    })
    return () => cancelAnimationFrame(id)
  }, [playing, duration])

  // anim
  useEffect(() => {
    if (playing && !animLocked.current) {
      animLocked.current = true
      controls.start({
        background: [
          "linear-gradient(135deg,#74ABE2,#5563DE)",
          "linear-gradient(135deg,#E27D60,#85DCBA)",
          "linear-gradient(135deg,#C38D9E,#41B3A3)",
          "linear-gradient(135deg,#74ABE2,#5563DE)",
        ],
        transition: { duration: 20, repeat: Infinity, ease: "linear" },
      })
    }
    if (!playing) {
      animLocked.current = false
      controls.stop()
    }
  }, [playing, controls])

  function ensureHowls() {
    if (mainRef.current) return
    const srcMain = `/audio/${avatar}/${audio}`
    try {
      mainRef.current = new Howl({
        src: [srcMain],
        html5: true,
        volume: 1,
        onend: handleEnd,
        onloaderror: (_, e) => setError(String(e)),
        onplayerror: async (_, e) => {
          // web audio unlock
          try { await Howler.ctx?.resume?.() } catch {}
          setError(String(e))
        },
      })
      if (hasBackgroundMusic && background && !bgRef.current) {
        bgRef.current = new Howl({
          src: [`/audio/${background}`],
          loop: true,
          volume: 0.3,
          html5: true,
        })
      }
    } catch (e: any) {
      setError(String(e?.message || e))
    }
  }

  async function startMeditation() {
    if (playing) return
    ensureHowls()
    const main = mainRef.current
    if (!main) return
    // user gesture = klick → autoplay-policy ok
    startTime.current = Date.now()
    setProgress(0)
    setPlaying(true)
    bgRef.current?.play()
    main.play()
  }

  function stopAll() {
    mainRef.current?.stop()
    bgRef.current?.stop()
    setPlaying(false)
    setProgress(0)
  }

  function handleEnd() {
    if (endCalled.current) return
    endCalled.current = true
    stopAll()
    onComplete?.()
    // erst nach Abschluss wieder freigeben
    setTimeout(() => { endCalled.current = false }, 0)
  }

  // cleanup beim unmount
  useEffect(() => {
    return () => {
      mainRef.current?.unload()
      bgRef.current?.unload()
      mainRef.current = null
      bgRef.current = null
    }
  }, [])

  return (
    <motion.div
      animate={controls}
      className="flex w-full flex-col items-center justify-center h-screen bg-zinc-800"
    >
      <h2 className="text-2xl font-semibold text-white mb-2">{title}</h2>
      <p className="text-white/80 text-center mb-8 max-w-md">{description}</p>

      {error && <p className="text-red-400 mb-4">{error}</p>}

      <div className="relative w-32 h-32">
        <svg className="absolute inset-0 w-full h-full -rotate-90" viewBox="0 0 100 100">
          <circle cx="50" cy="50" r="45" stroke="white" strokeWidth="6" fill="none" strokeOpacity="0.2" />
          <circle
            cx="50" cy="50" r="45" stroke="white" strokeWidth="6" fill="none"
            strokeDasharray={2 * Math.PI * 45}
            strokeDashoffset={(1 - progress) * 2 * Math.PI * 45}
            style={{ transition: "stroke-dashoffset 0.1s linear" }}
          />
        </svg>

        <button
          onClick={startMeditation}
          disabled={playing}
          className={`absolute inset-0 m-auto w-24 h-24 rounded-full ${
            !playing ? "bg-white text-gray-900" : "bg-gray-400 text-gray-700"
          } font-bold text-xl flex items-center justify-center shadow-lg active:scale-95 transition-transform`}
        >
          {playing ? "…" : "▶"}
        </button>
      </div>
    </motion.div>
  )
}
