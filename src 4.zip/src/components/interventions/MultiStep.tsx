import { useRef, useState, useEffect, memo } from "react"
import { Swiper, SwiperSlide } from "swiper/react"
import * as Templates from "."
import InterventionSuccess from "./InterventionSuccess"
import { useGame } from "../../context/GameContext"

type Slide = { template: string; skippable?: boolean; [key: string]: any }

type Props = {
  slides: Slide[]
  successXp?: number
  onAllDone: () => Promise<void> | void
  onComplete?: () => void
}

function MultiStep({ slides, successXp = 20, onAllDone, onComplete }: Props) {
  const swiperRef = useRef<any>(null)
  const [finished, setFinished] = useState(false)
  const doneOnce = useRef(false)
  const successTriggered = useRef(false)
  const stepLockRef = useRef<Record<number, boolean>>({})
  const { avatarName, avatarId } = useGame()

  useEffect(() => {
    console.log("🧱 MultiStep MOUNT")
    return () => console.log("💀 MultiStep UNMOUNT")
  }, [])

  // Letzten Slide automatisch skippable machen
  useEffect(() => {
    if (slides.length > 0 && slides[slides.length - 1].skippable === undefined) {
      slides[slides.length - 1].skippable = true
      if (import.meta.env.DEV)
        console.log("🧩 Letzter Slide automatisch auf skippable gesetzt (Dankesseite)")
    }
  }, [slides])

  // globale Unlock-Funktion (CSS + JS)
 const unlockVerticalSwiper = () => {
  const outerEl = document.querySelector(".swiper-initialized.swiper-vertical") as HTMLElement | null
  if (!outerEl) return
  const instance = (outerEl as any).swiper
  if (instance) {
    instance.allowTouchMove = true
    instance.update() // ⬅️ neu: zwingt Swiper, Zustand zu aktualisieren
  }
  outerEl.classList.remove("outer-no-swipe")
  document
    .querySelectorAll(".swiper-no-swiping")
    .forEach((el) => el.classList.remove("swiper-no-swiping"))
  if (import.meta.env.DEV) console.log("🔓 Vertikales Swipen erlaubt (unlockVerticalSwiper)")
}


  // nach Abschluss → dauerhaft freigeben
  useEffect(() => {
    if (!finished) return
    unlockVerticalSwiper()
    const retry1 = setTimeout(unlockVerticalSwiper, 300)
    const retry2 = setTimeout(unlockVerticalSwiper, 1200)
    const watch = setInterval(unlockVerticalSwiper, 2000)
    return () => {
      clearTimeout(retry1)
      clearTimeout(retry2)
      clearInterval(watch)
    }
  }, [finished])

  if (!avatarId) {
    return (
      <div className="flex items-center justify-center h-full bg-zinc-900 text-white">
        Lade Avatar …
      </div>
    )
  }

  return (
    <Swiper
      onSwiper={(swiper) => (swiperRef.current = swiper)}
      onSlideChangeTransitionStart={(swiper) => {
        const activeIndex = swiper.activeIndex
        const total = swiper.slides.length
        const isFirst = activeIndex === 0
        unlockVerticalSwiper()
        if (import.meta.env.DEV) console.log(`👀 SlideChangeTransitionStart → index: ${activeIndex}/${total}`)
        if (isFirst && finished) {
          setFinished(false)
          if (import.meta.env.DEV) console.log("♻️ finished-Status zurückgesetzt (Zurückswipen)")
        }
      }}
      direction="horizontal"
      slidesPerView={1}
      nested
      className="w-full h-full"
      noSwiping={true}
      noSwipingClass="swiper-no-swiping"
      observer
      observeParents
      watchSlidesProgress
      updateOnWindowResize={false}
      virtual={false}
    >
      {slides.map((slide, i) => {
        const Component = (Templates as any)[slide.template]
        const isLast = i === slides.length - 1
        const nonSwipeClass = slide.skippable === false ? "swiper-no-swiping" : ""

        if (import.meta.env.DEV) {
          console.log(
            `${slide.skippable === false ? "🚫" : "➡️"} Inner Slide "${slide.template}" [#${i}] ${
              slide.skippable === false ? "NOT skippable" : "skippable"
            }`
          )
        }

        const mergedProps = {
          ...slide.props,
          xp: slide.xp ?? 0,
          avatarName,
          avatarId,
        }

        const onStepComplete = async (cancelled?: boolean) => {
          const swiper = swiperRef.current
          if (!swiper) return
          if (stepLockRef.current[i]) return
          stepLockRef.current[i] = true

          // Abbruch → nur Swipen wieder erlauben
          if (cancelled) {
            if (import.meta.env.DEV) console.log("❌ MultiStep: abgebrochen, kein XP, kein Wechsel")
            unlockVerticalSwiper()
            return
          }

          // Normaler Fortschritt → nächster Slide
          if (!isLast) {
            if (import.meta.env.DEV)
              console.log(`➡️ MultiStep: Slide [${i}] abgeschlossen → weiter zu [${i + 1}]`)
            swiper.slideNext()
            return
          }

          // Letzter Slide
          if (!doneOnce.current) {
            doneOnce.current = true
            if (slide.xp && slide.xp > 0) {
              window.dispatchEvent(new CustomEvent("grant-xp", { detail: slide.xp }))
              if (import.meta.env.DEV) console.log(`💎 XP vergeben: ${slide.xp}`)
            }
            unlockVerticalSwiper()
            setFinished(true)
            if (import.meta.env.DEV) console.log("🏁 MultiStep abgeschlossen → Success wird angezeigt")
            setTimeout(() => swiper.slideNext(), 0)
          }
        }

        return (
          <SwiperSlide key={i} className={`!h-full ${nonSwipeClass}`}>
            <div className="flex items-center justify-center h-full bg-zinc-800">
              {Component ? (
                <Component {...mergedProps} onComplete={onStepComplete} />
              ) : (
                <div>❌ Template nicht gefunden {slide.template}</div>
              )}
            </div>
          </SwiperSlide>
        )
      })}

      {finished && (
        <SwiperSlide>
          <div className="flex items-center justify-center h-full bg-zinc-900">
            <InterventionSuccess
              xp={Number(successXp) || 0}
              onReady={() => {
                if (successTriggered.current) return
                successTriggered.current = true
                console.log("🏁 MultiStep → Success onReady einmalig ausgeführt")
                onAllDone?.()
              }}
            />
          </div>
        </SwiperSlide>
      )}
    </Swiper>
  )
}

export default memo(MultiStep, (prev, next) => {
  return (
    prev.successXp === next.successXp &&
    prev.onAllDone === next.onAllDone &&
    prev.onComplete === next.onComplete &&
    JSON.stringify(prev.slides) === JSON.stringify(next.slides)
  )
})
