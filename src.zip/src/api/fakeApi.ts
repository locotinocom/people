// src/api/fakeApi.ts

import interventionsData from "../data/interventions.json"
import type { StepProgress, GameState } from "./types"
import type { ApiInterface } from "./types"

const delay = (ms: number) => new Promise((r) => setTimeout(r, ms))

export const fakeApi = {

  async getUser() {
    await delay(200)
    return {
      id: 1,
      name: localStorage.getItem("avatarName") || "Tim",
      avatarId: localStorage.getItem("avatarId") || "tim-dummy",
      level: Number(localStorage.getItem("level")) || 1,
      xp: Number(localStorage.getItem("xp")) || 0,
      rewards: JSON.parse(localStorage.getItem("rewards") || "[]"),
      data: JSON.parse(localStorage.getItem("data") || "{}"),
    }
  },

  async setAvatar(avatarName: string, avatarId: string) {
    console.log("💾 fakeApi.setAvatar", { avatarName, avatarId })
    localStorage.setItem("avatarName", avatarName)
    localStorage.setItem("avatarId", avatarId)
    return { success: true }
  },

  // 🧠 Spielzustand laden/speichern
  async getGameState(): Promise<GameState> {
    await delay(150)
    return JSON.parse(localStorage.getItem("gameState") || "{}") || {
      level: 1,
      xp: 0,
      dias: 0,
      completedInterventions: [],
      avatarId: null,
      avatarName: null,
      answers: {},
    }
  },

  async saveGameState(data: GameState) {
    await delay(100)
    localStorage.setItem("gameState", JSON.stringify(data))
    return { success: true }
  },

  // 📘 Interventionen
  async getInterventions(level: number) {
    await delay(300)
    return (interventionsData as any[])
      .map((item, index) => ({ ...item, id: index + 1, order: index + 1 }))
      .filter((i) => i.level === level)
  },

  // 👤 Avatar
  async updateAvatar(name: string, avatarId: string) {
    await delay(150)
    localStorage.setItem("avatarName", name)
    localStorage.setItem("avatarId", avatarId)
    return { success: true }
  },

  // 🪄 Fortschritt
  async updateProgress(interventionId: number, xp: number) {
    await delay(150)
    const state = JSON.parse(localStorage.getItem("gameState") || "{}") || {}
    const completed = state.completedInterventions || []

    if (!completed.includes(interventionId)) completed.push(interventionId)
    state.completedInterventions = completed
    state.xp = (state.xp || 0) + xp

    localStorage.setItem("gameState", JSON.stringify(state))
    return { success: true, xp: state.xp }
  },

  async getRewards() {
    await delay(200)
    return JSON.parse(localStorage.getItem("rewards") || "[]")
  },

  async grantDiamonds(amount: number) {
    const state = JSON.parse(localStorage.getItem("gameState") || "{}") || {}
    state.dias = (state.dias || 0) + amount
    localStorage.setItem("gameState", JSON.stringify(state))
    return { success: true, dias: state.dias }
  },

  // 📍 Aktueller Fortschritt
  async getCurrentStep(): Promise<StepProgress> {
    const idx = Number(localStorage.getItem("currentStep") || "0")
    return { stepIndex: idx }
  },

  async updateCurrentStep(stepIndex: number) {
    await delay(100)
    localStorage.setItem("currentStep", String(stepIndex))
    if (import.meta.env.DEV) console.log("🧪 fakeApi.updateCurrentStep", stepIndex)
    return { success: true }
  },

  // 🔄 Reset
  async resetProgress(): Promise<{ success: boolean }> {
    localStorage.clear()
    return { success: true }
  },
}
