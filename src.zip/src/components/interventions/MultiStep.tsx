import { useRef, useState } from "react"
import { Swiper, SwiperSlide } from "swiper/react"
import * as Templates from "."
import InterventionSuccess from "./InterventionSuccess"
import { useGame } from "../../context/GameContext"   // ✅ RICHTIGER Hook!

type Slide = { template: string; [key: string]: any }

type Props = {
  slides: Slide[]
  successXp?: number
  onAllDone: () => Promise<void> | void
}

export default function MultiStep({ slides, successXp = 20, onAllDone }: Props) {
  const [finished, setFinished] = useState(false)
  const doneOnce = useRef(false)

  // ✅ Avatarname und -ID aus dem globalen Context (API-basiert!)
  const { avatarName, avatarId } = useGame()

  console.log("👤 Aktueller Avatar:", { avatarName, avatarId })

  return (
    <Swiper direction="horizontal" slidesPerView={1} nested className="w-full h-full">
      {slides.map((slide, i) => {
        const Component = (Templates as any)[slide.template]
        const isLast = i === slides.length - 1

        // 🔄 Props erweitern – Avatarname oder ID automatisch einfügen
        const mergedProps = {
          ...slide,
          ...slide.props,
           xp: slide.xp ?? 0,
          avatarName,
          avatarId,
        }

        const onComplete = async () => {
          if (!isLast) {
            const el = document.querySelector(".swiper-initialized.swiper-horizontal") as any
            el?.swiper?.slideNext()
            return
          }

          if (doneOnce.current) return
          doneOnce.current = true
          setFinished(true)

          setTimeout(() => {
            const el = document.querySelector(".swiper-initialized.swiper-horizontal") as any
            el?.swiper?.slideNext()
          }, 0)
        }

        return (
          <SwiperSlide key={i}>
            <div className="flex items-center justify-center h-full bg-zinc-800">
              {Component ? (
                <Component {...mergedProps} onComplete={onComplete} />
              ) : (
                <div>❌ Template nicht gefunden {slide.template}</div>
              )}
            </div>
          </SwiperSlide>
        )
      })}

      {finished && (
        <SwiperSlide>
          <div className="flex items-center justify-center h-full bg-zinc-900">
            <InterventionSuccess xp={Number(successXp) || 0} onReady={onAllDone} />
          </div>
        </SwiperSlide>
      )}
    </Swiper>
  )
}
