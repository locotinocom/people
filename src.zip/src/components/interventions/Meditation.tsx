import { useState, useEffect, useRef } from "react"
import { Howl } from "howler"
import { motion, useAnimation } from "framer-motion"
import { useGame } from "../../context/GameContext"  // 👈 Zugriff auf Avatar aus API

type Props = {
  title: string
  description: string
  audio: string
  background?: string
  hasBackgroundMusic?: boolean
  duration: number // Sekunden
  onComplete?: () => void
}

export default function Meditation({
  title,
  description,
  audio,
  background,
  hasBackgroundMusic = false,
  duration,
  onComplete,
}: Props) {
  const { avatarId, avatarName } = useGame() // ✅ automatisch aus API
  const avatar = avatarId || "tim" // Fallback, falls noch nichts gewählt

  const [playing, setPlaying] = useState(false)
  const [progress, setProgress] = useState(0)
  const [loaded, setLoaded] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const controls = useAnimation()

  const meditationSound = useRef<Howl | null>(null)
  const ambientSound = useRef<Howl | null>(null)
  const startTime = useRef<number | null>(null)

  console.log("🎧 Rendering Meditation Component", {
    avatar,
    avatarName,
    audio,
    background,
  })

  // 🧠 Audio initialisieren
  useEffect(() => {
    if (!audio || !avatar) {
      console.warn("⚠️ Meditation: audio oder avatar fehlen", { audio, avatar })
      return
    }

    const audioPath = `/audio/${avatar}/${audio}`
    console.log("🎶 Initialisiere Hauptaudio:", audioPath)

    meditationSound.current = new Howl({
      src: [audioPath],
      volume: 1.0,
      html5: true,
      onload: () => {
        console.log("✅ Hauptaudio geladen:", audioPath)
        setLoaded(true)
      },
      onloaderror: (_, err) => {
        console.error("❌ Hauptaudio-Fehler:", err)
        setError("Audiodatei konnte nicht geladen werden.")
      },
      onplay: () => console.log("▶️ Wiedergabe gestartet:", audioPath),
      onend: () => {
        console.log("🏁 Wiedergabe beendet")
        handleEnd()
      },
      onplayerror: (_, err) => {
        console.error("🚫 Wiedergabe-Fehler:", err)
        setError("Audio konnte nicht abgespielt werden.")
      },
    })

    if (hasBackgroundMusic && background) {
      const bgPath = `/audio/${background}`
      console.log("🌿 Lade Hintergrundmusik:", bgPath)

      ambientSound.current = new Howl({
        src: [bgPath],
        loop: true,
        volume: 0.3,
        html5: true,
        onload: () => console.log("✅ Hintergrundmusik geladen:", bgPath),
        onloaderror: (_, err) =>
          console.error("❌ Hintergrundmusik-Fehler:", err),
      })
    }

    return () => {
      meditationSound.current?.unload()
      ambientSound.current?.unload()
    }
  }, [audio, avatar, background, hasBackgroundMusic])

  // 🌀 Hintergrund animieren
  useEffect(() => {
    if (playing) {
      controls.start({
        background: [
          "linear-gradient(135deg,#74ABE2,#5563DE)",
          "linear-gradient(135deg,#E27D60,#85DCBA)",
          "linear-gradient(135deg,#C38D9E,#41B3A3)",
          "linear-gradient(135deg,#74ABE2,#5563DE)",
        ],
        transition: { duration: 20, repeat: Infinity, ease: "linear" },
      })
    } else {
      controls.stop()
    }
  }, [playing, controls])

  // 🎚 Fortschritt updaten
  useEffect(() => {
    let frame: number
    const update = () => {
      if (playing && startTime.current) {
        const elapsed = (Date.now() - startTime.current) / 1000
        setProgress(Math.min(elapsed / duration, 1))
      }
      frame = requestAnimationFrame(update)
    }
    frame = requestAnimationFrame(update)
    return () => cancelAnimationFrame(frame)
  }, [playing, duration])

  function startMeditation() {
    if (playing || !loaded) {
      console.warn("⏸️ Noch nicht bereit oder schon laufend", { playing, loaded })
      return
    }

    const main = meditationSound.current
    if (!main) {
      console.error("❌ Kein Hauptaudio initialisiert")
      return
    }

    console.log("▶️ Starte Meditation mit:", audio)
    startTime.current = Date.now()
    setPlaying(true)
    main.play()
    ambientSound.current?.play()
  }

  function stopAll() {
    meditationSound.current?.stop()
    ambientSound.current?.stop()
    setPlaying(false)
    setProgress(0)
  }

  function handleEnd() {
    stopAll()
    onComplete?.()
  }

  return (
    <motion.div
      animate={controls}
      className="flex w-full flex-col items-center justify-center h-screen transition-all duration-1000 bg-zinc-800"
    >
      <h2 className="text-2xl font-semibold text-white mb-2">{title}</h2>
      <p className="text-white/80 text-center mb-8 max-w-md">{description}</p>

      {error && <p className="text-red-400 mb-4">{error}</p>}
      {!loaded && !error && <p className="text-white/50 mb-4">⏳ Lade Audio…</p>}

      <div className="relative w-32 h-32">
        {/* Fortschrittsring */}
        <svg
          className="absolute top-0 left-0 w-full h-full transform -rotate-90"
          viewBox="0 0 100 100"
        >
          <circle
            cx="50"
            cy="50"
            r="45"
            stroke="white"
            strokeWidth="6"
            fill="none"
            strokeOpacity="0.2"
          />
          <circle
            cx="50"
            cy="50"
            r="45"
            stroke="white"
            strokeWidth="6"
            fill="none"
            strokeDasharray={2 * Math.PI * 45}
            strokeDashoffset={(1 - progress) * 2 * Math.PI * 45}
            style={{ transition: "stroke-dashoffset 0.1s linear" }}
          />
        </svg>

        {/* Play-Button */}
        <button
          onClick={startMeditation}
          disabled={!loaded || playing}
          className={`absolute inset-0 m-auto w-24 h-24 rounded-full ${
            loaded ? "bg-white text-gray-900" : "bg-gray-400 text-gray-700"
          } font-bold text-xl flex items-center justify-center shadow-lg active:scale-95 transition-transform`}
        >
          {playing ? "…" : "▶"}
        </button>
      </div>
    </motion.div>
  )
}
