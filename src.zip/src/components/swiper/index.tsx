import { Swiper, SwiperSlide } from "swiper/react"
import { useGame } from "../../context/GameContext"
import type { RefObject } from "react"
import interventionsData from "../../data/interventions.json"
import type { Intervention } from "../../types/intervention"
import { useInterventionLogic } from "./useInterventionLogic"
import { useRenderHelpers } from "./useRenderHelpers"
import { useInterventionProgress } from "./useInterventionProgress"

type Props = {
  spawnXp: (amount: number, durationOverride?: number) => Promise<void> | void
  xpTargetRef: RefObject<HTMLDivElement | null>
  diaTargetRef: RefObject<HTMLDivElement | null>
  swiperRef?: React.RefObject<any>
  setStepIndex?: (idx: number) => void
  setInitialSlide?: (idx: number) => void
}

export default function InterventionSwiper({
  spawnXp,
  swiperRef,
  setStepIndex,
  setInitialSlide,
}: Props) {
  const { level, completedInterventions } = useGame()
  const { handleSingleComplete, grantMultiXp } = useInterventionLogic(spawnXp)
  const { renderSingle, renderMultiStep } = useRenderHelpers(spawnXp)
  const { stepIndex, initialSlide, setProgress, resetProgress } =
    useInterventionProgress(setStepIndex, setInitialSlide)

  const interventions: Intervention[] = (interventionsData as Intervention[]).map((item, index) => ({
    ...item,
    id: index + 1,
    order: index + 1,
  }))

  const verticalList = interventions
    .filter((i) => i.level === level && !completedInterventions.includes(i.id!))
    .sort((a, b) => (a.order ?? 0) - (b.order ?? 0))

  return (
    <>
      <Swiper
        onSwiper={(swiper) => {
          if (swiperRef) (swiperRef as any).current = swiper
        }}
        direction="vertical"
        slidesPerView={1}
        className="h-full w-full overflow-hidden"
        initialSlide={initialSlide}
        onSlideChange={(s) => setProgress(s.activeIndex)}
      >
        {verticalList.map((intervention, vIdx) => (
          <SwiperSlide className="!h-full overflow-hidden" key={intervention.id}>
            {intervention.template === "MultiStep" || intervention.type !== "single"
              ? renderMultiStep(intervention, () =>
                  grantMultiXp(intervention, vIdx)
                )
              : renderSingle(intervention, () => handleSingleComplete(intervention))}
          </SwiperSlide>
        ))}
      </Swiper>

      {/* Debug Button */}
      <div className="absolute bottom-2 right-2">
        <button
          onClick={() => resetProgress(swiperRef)}
          className="px-3 py-1 bg-red-600 rounded text-sm"
        >
          Neustart
        </button>
      </div>
    </>
  )
}