import { useEffect, useRef, useState } from "react"
import { Swiper, SwiperSlide } from "swiper/react"
import { useGame } from "../context/GameContext"
import type { RefObject } from "react"
import interventionsData from "../data/interventions.json"
import type { Intervention } from "../types/intervention"
import MultiStep from "./interventions/MultiStep"
import { api } from "../api"

const modules = import.meta.glob("./interventions/*.tsx", { eager: true })
const componentMap: Record<string, React.ComponentType<any>> = {}
for (const path in modules) {
  const mod: any = modules[path]
  const name = path.split("/").pop()?.replace(".tsx", "") || ""
  if (mod?.default) componentMap[name] = mod.default
}

type Props = {
  spawnXp: (amount: number, durationOverride?: number) => Promise<void> | void
  xpTargetRef: RefObject<HTMLDivElement | null>
  diaTargetRef: RefObject<HTMLDivElement | null>
  swiperRef?: React.RefObject<any>
  setStepIndex?: (idx: number) => void
  setInitialSlide?: (idx: number) => void
}

export default function InterventionSwiper({
  spawnXp,
  xpTargetRef,
  diaTargetRef,
  swiperRef,
  setStepIndex: externalSetStepIndex,
  setInitialSlide: externalSetInitialSlide,
}: Props) {
  const { level, grantReward, markInterventionDone, completedInterventions } = useGame()

  const [pending, setPending] = useState<{ id: number; vIndex: number } | null>(null)
  const [stepIndex, internalSetStepIndex] = useState(0)
  const [initialSlide, internalSetInitialSlide] = useState(0)
  const awardingSingle = useRef<Set<number>>(new Set())

  // 📌 Fortschritt laden
  useEffect(() => {
    let mounted = true
    api.getCurrentStep().then((res: any) => {
      if (mounted && res?.stepIndex !== undefined) {
        internalSetStepIndex(res.stepIndex)
        internalSetInitialSlide(res.stepIndex)
        externalSetStepIndex?.(res.stepIndex)
        externalSetInitialSlide?.(res.stepIndex)
      }
    })
    return () => {
      mounted = false
    }
  }, [])

  // 🪜 Nur aktuelle Level-Interventionen
  const interventions: Intervention[] = (interventionsData as Intervention[]).map((item, index) => ({
    ...item,
    id: index + 1,
    order: index + 1,
  }))

  const verticalList = interventions
    .filter(
      (i) =>
        i.level === level &&
        (!completedInterventions.includes(i.id!) || (pending && pending.id === i.id))
    )
    .sort((a, b) => (a.order ?? 0) - (b.order ?? 0))

  // ✅ Einzelintervention abschließen
  const handleSingleComplete = (intervention: Intervention) => {
    if (!intervention.id) return
    if (awardingSingle.current.has(intervention.id)) return
    awardingSingle.current.add(intervention.id)

    const xp = typeof intervention.xp === "number" ? intervention.xp : 0
    if (xp > 0) {
      const count = Math.min(Math.max(1, Math.floor(xp)), 200)
      const totalMs = (count - 1) * 50 + 1200
      spawnXp(xp, totalMs)
      grantReward({ type: "xp", amount: xp, meta: { duration: totalMs } })

      setTimeout(() => {
        markInterventionDone(intervention.id!)
        awardingSingle.current.delete(intervention.id!)
      }, totalMs)
    } else {
      markInterventionDone(intervention.id!)
      awardingSingle.current.delete(intervention.id!)
    }
  }

  // 🧠 Platzhalter ersetzen
  const replaceAvatarName = (value: any): any => {
    const rawAvatarName = localStorage.getItem("avatarName") || "dein Begleiter"
    const avatarName = rawAvatarName.charAt(0).toUpperCase() + rawAvatarName.slice(1)

    if (typeof value === "string") {
      return value.replace(/\{\{avatarName\}\}/g, avatarName)
    } else if (typeof value === "object" && value !== null) {
      const result: Record<string, any> = {}
      for (const key in value) result[key] = replaceAvatarName(value[key])
      return result
    }
    return value
  }

  // 🧩 Einzelne Intervention rendern
  const renderSingle = (intervention: Intervention) => {
    const Component = componentMap[intervention.template]
    if (!Component) return <div className="text-gray-400">❌ Template: {intervention.template}</div>

    const props = replaceAvatarName({
      ...intervention.props,
      xp: intervention.xp,
      level: intervention.level,
      bubble: intervention.props?.bubble ?? false,
      onComplete: () => handleSingleComplete(intervention),
    })

    return <Component {...props} />
  }

  // 🧭 Swiper
  return (
    <>
      <Swiper
  onSwiper={(swiper) => {
    if (swiperRef) (swiperRef as any).current = swiper
  }}
  direction="vertical"
  slidesPerView={1}
  className="h-full w-full overflow-hidden"
  initialSlide={initialSlide}
  allowSlideNext={verticalList[stepIndex]?.skippable !== false}
  onSlideChange={async (s) => {
    const idx = s.activeIndex
    internalSetStepIndex(idx)
    externalSetStepIndex?.(idx)
    await api.updateCurrentStep(idx)
    if (pending && idx !== pending.vIndex) {
      markInterventionDone(pending.id)
      setPending(null)
    }
  }}
>

        {verticalList.map((intervention: Intervention, vIdx: number) => {
          const type = intervention.type ?? "single"

          return (
            <SwiperSlide className="!h-full overflow-hidden" key={intervention.id}>
              {intervention.template === "MultiStep" || type !== "single" ? (
                <div className="h-full overflow-y-auto overflow-x-hidden flex justify-center items-center bg-zinc-900">
                  <MultiStep
                    slides={intervention.props?.slides ?? []}
                    successXp={intervention.xp ?? 20}
                    onAllDone={() => {
                      if (!intervention.id) return
                      const xp = typeof intervention.xp === "number" ? intervention.xp : 20
                      const count = Math.min(Math.max(1, Math.floor(xp)), 200)
                      const totalMs = (count - 1) * 50 + 1200
                      spawnXp(xp, totalMs)
                      grantReward({ type: "xp", amount: xp, meta: { duration: totalMs } })
                      setPending({ id: intervention.id, vIndex: vIdx })
                    }}
                  />
                </div>
              ) : (
                <div className="flex items-center justify-center h-full bg-zinc-800">
                  {renderSingle(intervention)}
                </div>
              )}
            </SwiperSlide>
          )
        })}
      </Swiper>

      {/* 🔧 Debug-Reset */}
      <div className="absolute bottom-2 right-2">
        <button
          onClick={async () => {
            await api.resetProgress()
            internalSetStepIndex(0)
            internalSetInitialSlide(0)
            externalSetStepIndex?.(0)
            externalSetInitialSlide?.(0)
            swiperRef?.current?.slideTo(0, 0)
          }}
          className="px-3 py-1 bg-red-600 rounded text-sm"
        >
          Neustart
        </button>
      </div>
    </>
  )
}
