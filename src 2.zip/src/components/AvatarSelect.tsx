import React, { useEffect, useState } from "react"
import { Canvas } from "@react-three/fiber"
import { OrbitControls, useGLTF } from "@react-three/drei"

type Template = {
  id: string
  gender: string
  imageUrl: string
}

type Avatar = {
  id: string
  glb: string
  gender: string
}

// Loader für GLB
function AvatarModel({ url }: { url: string }) {
  const { scene } = useGLTF(url)
  return <primitive object={scene} scale={1.5} />
}

export default function AvatarSelect() {
  const [token, setToken] = useState<string | null>(null)
  const [templates, setTemplates] = useState<Template[]>([])
  const [selectedTemplate, setSelectedTemplate] = useState<Template | null>(
    null
  )
  const [draft, setDraft] = useState<Avatar | null>(null)
  const [loading, setLoading] = useState(true)
  const [show3D, setShow3D] = useState(false)

  // 1. User erstellen und Token holen
  const createUser = async () => {
    const res = await fetch(
      `https://${import.meta.env.VITE_RPM_APP_SUBDOMAIN}.readyplayer.me/api/users`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          data: {
            applicationId: import.meta.env.VITE_RPM_APP_ID,
          },
        }),
      }
    )
    const data = await res.json()
    return data.data.token as string
  }

  // 2. Templates holen
  const getTemplates = async (token: string) => {
    const res = await fetch("https://api.readyplayer.me/v2/avatars/templates", {
      headers: { Authorization: `Bearer ${token}` },
    })
    const data = await res.json()
    return data.data as Template[]
  }

  // 3. Draft-Avatar aus Template erstellen
  const createDraftAvatar = async (token: string, template: Template) => {
    const res = await fetch(
      `https://api.readyplayer.me/v2/avatars/templates/${template.id}`,
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          data: {
            partner: import.meta.env.VITE_RPM_APP_SUBDOMAIN,
            bodyType: "fullbody",
          },
        }),
      }
    )

    if (!res.ok) {
      const errorText = await res.text()
      throw new Error(`Draft creation failed: ${res.status} ${errorText}`)
    }

    const data = await res.json()
    return {
      id: data.data.id,
      glb: `https://api.readyplayer.me/v2/avatars/${data.data.id}.glb?preview=true`,
      gender: template.gender,
    }
  }

  useEffect(() => {
    const init = async () => {
      try {
        setLoading(true)
        const t = await createUser()
        setToken(t)

        const all = await getTemplates(t)
        // als Demo nur male + female template nehmen
        const male = all.find((tpl) => tpl.gender === "male")
        const female = all.find((tpl) => tpl.gender === "female")
        setTemplates([male!, female!].filter(Boolean) as Template[])
      } catch (err) {
        console.error("Avatar API Error:", err)
      } finally {
        setLoading(false)
      }
    }
    init()
  }, [])

  const handleSelect = async (tpl: Template) => {
    if (!token) return
    setSelectedTemplate(tpl)
    const d = await createDraftAvatar(token, tpl)
    setDraft(d)
  }

  return (
    <div className="flex flex-col items-center gap-4 p-6">
      <h2 className="text-2xl font-bold">Wähle deinen Avatar</h2>

      {loading && <p className="text-gray-400">Lade Avatare ...</p>}

      <div className="grid grid-cols-2 gap-6">
        {templates.map((tpl) => (
          <button
            key={tpl.id}
            onClick={() => handleSelect(tpl)}
            className={`border-4 rounded-lg overflow-hidden ${
              selectedTemplate?.id === tpl.id
                ? "border-blue-500"
                : "border-transparent"
            }`}
          >
            <img src={tpl.imageUrl} alt="avatar template" />
            <p className="text-center capitalize">{tpl.gender}</p>
          </button>
        ))}
      </div>

      {draft && (
        <div className="mt-6 text-center">
          <p className="mb-2 font-semibold">Dein Avatar:</p>

          {!show3D ? (
            <>
              <img
                src={selectedTemplate?.imageUrl}
                alt="selected avatar"
                className="w-48 h-48 border rounded-lg"
              />
              <button
                onClick={() => setShow3D(true)}
                className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg"
              >
                In 3D anzeigen
              </button>
            </>
          ) : (
            <div className="w-full h-[400px] bg-gray-900 rounded-lg">
              <Canvas camera={{ position: [0, 1.6, 2.8], fov: 30 }}>
                <ambientLight intensity={0.8} />
                <directionalLight position={[2, 2, 2]} />
                <React.Suspense fallback={null}>
                  <AvatarModel url={draft.glb} />
                </React.Suspense>
                <OrbitControls
                  target={[0, 1.4, 0]}
                  enablePan={false}
                  minDistance={1.8}
                  maxDistance={3.5}
                />
              </Canvas>
              <button
                onClick={() => setShow3D(false)}
                className="mt-4 px-4 py-2 bg-gray-600 text-white rounded-lg"
              >
                Zurück zur Vorschau
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
