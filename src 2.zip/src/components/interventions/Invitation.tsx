import { useState, useEffect } from "react"

type Props = {
  title?: string
  message: string
  yesText?: string
  noText?: string
  xp?: number
  onComplete: () => void
}

export default function Invitation({
  title = "Einladung",
  message,
  yesText = "Ja, gerne 🧘‍♀️",
  noText = "Vielleicht später",
  xp,
  onComplete,
}: Props) {
  const [declined, setDeclined] = useState(false)

  useEffect(() => {
    if (declined) {
      const timer = setTimeout(() => onComplete(), 2500)
      return () => clearTimeout(timer)
    }
  }, [declined, onComplete])

  if (declined) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center text-white p-6">
        <h2 className="text-xl font-semibold mb-2">Alles klar 😌</h2>
        <p className="text-lg text-gray-200">
          Dann vielleicht später 😉<br />Ich warte so lange auf dich...
        </p>
      </div>
    )
  }

  return (
    <div className="flex flex-col items-center justify-center text-center h-full p-6 text-white">
      <h2 className="text-2xl font-bold mb-4">{title}</h2>
      <p className="text-lg mb-8 max-w-sm">{message}</p>

      <div className="flex gap-4">
        <button
          onClick={onComplete}
          className="px-6 py-3 bg-green-600 rounded-lg text-white font-bold hover:bg-green-500"
        >
          {yesText}
        </button>
        <button
          onClick={() => setDeclined(true)}
          className="px-6 py-3 bg-gray-600 rounded-lg text-white font-bold hover:bg-gray-500"
        >
          {noText}
        </button>
      </div>

      {typeof xp === "number" && xp > 0 && (
        <p className="mt-4 text-sm text-gray-400">Erledigen bringt +{xp} XP</p>
      )}
    </div>
  )
}
