import { Swiper, SwiperSlide } from "swiper/react"
import { useGame } from "../../context/GameContext"
import { useCallback, useMemo, type RefObject } from "react"
import interventionsData from "../../data/interventions.json"
import type { Intervention } from "../../types/intervention"
import { useInterventionLogic } from "./useInterventionLogic"
import { useRenderHelpers } from "./useRenderHelpers"
import { useInterventionProgress } from "./useInterventionProgress"

type Props = {
  spawnXp: (amount: number, durationOverride?: number) => Promise<void> | void
  xpTargetRef: RefObject<HTMLDivElement | null>
  diaTargetRef: RefObject<HTMLDivElement | null>
  swiperRef?: React.RefObject<any>
  setStepIndex?: (idx: number) => void
  setInitialSlide?: (idx: number) => void
}

export default function InterventionSwiper({
  spawnXp,
  swiperRef,
  setStepIndex,
  setInitialSlide,
}: Props) {
  // ✅ ALLE HOOKS AUF TOP-LEVEL
  const { level, completedInterventions } = useGame()
  const { handleSingleComplete, grantMultiXp } = useInterventionLogic(spawnXp)
  const { renderSingle, renderMultiStep } = useRenderHelpers(spawnXp)
  const { initialSlide, setProgress, resetProgress } =
    useInterventionProgress(setStepIndex, setInitialSlide)

  // 📜 Interventionen vorbereiten
  const interventions: Intervention[] = useMemo(
    () =>
      (interventionsData as Intervention[]).map((item, index) => ({
        ...item,
        id: index + 1,
        order: index + 1,
      })),
    []
  )

  const verticalList = useMemo(
    () =>
      interventions
        .filter((i) => i.level === level && !completedInterventions.includes(i.id!))
        .sort((a, b) => (a.order ?? 0) - (b.order ?? 0)),
    [interventions, level, completedInterventions]
  )

  const handleGrantMultiXp = useCallback(
    (intervention: Intervention) => grantMultiXp(intervention),
    [grantMultiXp]
  )

  const handleSingle = useCallback(
    (intervention: Intervention) => handleSingleComplete(intervention),
    [handleSingleComplete]
  )

  const slides = useMemo(
    () =>
      verticalList.map((intervention) => (
        <SwiperSlide className="!h-full overflow-hidden" key={intervention.id}>
          {intervention.template === "MultiStep" || intervention.type !== "single"
            ? renderMultiStep(intervention, () => handleGrantMultiXp(intervention))
            : renderSingle(intervention, () => handleSingle(intervention))}
        </SwiperSlide>
      )),
    [verticalList, renderMultiStep, renderSingle, handleGrantMultiXp, handleSingle]
  )

  return (
    <>
      <Swiper
        onSwiper={(swiper) => {
          if (swiperRef) (swiperRef as any).current = swiper
        }}
        direction="vertical"
        slidesPerView={1}
        className="h-full w-full overflow-hidden"
        initialSlide={initialSlide}
        onSlideChange={(s) => setProgress(s.activeIndex)}
        virtual={false}               // Deaktiviert virtuelles Entfernen
  observer={true}               // Beobachtet DOM-Änderungen
  observeParents={true}
  watchSlidesProgress={true}
  updateOnWindowResize={false}
      >
        {slides}
      </Swiper>

      <div className="absolute bottom-2 right-2">
        <button
          onClick={() => resetProgress(swiperRef)}
          className="px-3 py-1 bg-red-600 rounded text-sm"
        >
          Neustart
        </button>
      </div>
    </>
  )
}
