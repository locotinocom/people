import { useCallback, useEffect, useMemo } from "react"
import { useGame } from "../../context/GameContext"
import MultiStep from "../interventions/MultiStep"

// 🧱 Komponenten registrieren (einmalig, außerhalb der Hook!)
const modules = import.meta.glob("../interventions/*.tsx", { eager: true })
const componentMap: Record<string, React.ComponentType<any>> = {}

for (const path in modules) {
  const mod: any = modules[path]
  const name = path.split("/").pop()?.replace(".tsx", "") || ""
  if (mod?.default) componentMap[name] = mod.default
}

// ✅ Keine Hook-Aufrufe außerhalb erlaubter Stellen
export function useRenderHelpers(spawnXp: (amount: number, durationOverride?: number) => void) {
  // Hook-Aufruf ganz oben
  const { grantReward } = useGame()

  useEffect(() => {
    console.log("🧠 useRenderHelpers initialisiert")
    return () => console.log("💀 useRenderHelpers unmounted")
  }, [])

  // 🔹 Name ersetzen (reine Utility-Funktion, kein Hook!)
  const replaceAvatarName = useCallback((value: any): any => {
    const raw = localStorage.getItem("avatarName") || "dein Begleiter"
    const name = raw.charAt(0).toUpperCase() + raw.slice(1)
    if (typeof value === "string") return value.replace(/\{\{avatarName\}\}/g, name)
    if (typeof value === "object" && value !== null) {
      const result: Record<string, any> = {}
      for (const key in value) result[key] = replaceAvatarName(value[key])
      return result
    }
    return value
  }, [])

  // 🔹 renderSingle
  const renderSingle = useCallback(
    (intervention: any, onComplete: () => void) => {
      console.log("🧩 renderSingle:", intervention.title)
      const Component = componentMap[intervention.template]
      if (!Component)
        return <div className="text-gray-400">❌ Template: {intervention.template}</div>

      const props = replaceAvatarName({
        ...intervention.props,
        xp: intervention.xp,
        onComplete,
      })
      return <Component {...props} />
    },
    [replaceAvatarName]
  )

  // 🔹 renderMultiStep
  const renderMultiStep = useCallback(
    (intervention: any, onDone: () => void) => {
      console.log("🧩 renderMultiStep:", intervention.title)
      const xp = typeof intervention.xp === "number" ? intervention.xp : 20

      return (
        <MultiStep
          slides={intervention.props?.slides ?? []}
          successXp={xp}
          onAllDone={() => {
            spawnXp(xp)
            grantReward({ type: "xp", amount: xp })
            onDone()
          }}
        />
      )
    },
    [spawnXp, grantReward]
  )

  useEffect(() => {
    console.log("✅ useRenderHelpers bereit")
  }, [])

  // ✅ Hooks nur auf Top-Level, daher hier Rückgabe der Renderfunktionen
  return useMemo(
    () => ({ renderSingle, renderMultiStep }),
    [renderSingle, renderMultiStep]
  )
}
