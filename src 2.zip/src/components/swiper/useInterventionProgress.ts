import { useEffect, useState } from "react"
import { api } from "../../api"

export function useInterventionProgress(
  externalSetStepIndex?: (idx: number) => void,
  externalSetInitialSlide?: (idx: number) => void
) {
  const [stepIndex, setStepIndex] = useState(0)
  const [initialSlide, setInitialSlide] = useState(0)

  useEffect(() => {
    api.getCurrentStep().then((res: any) => {
      if (res?.stepIndex !== undefined) {
        setStepIndex(res.stepIndex)
        setInitialSlide(res.stepIndex)
        externalSetStepIndex?.(res.stepIndex)
        externalSetInitialSlide?.(res.stepIndex)
      }
    })
  }, [])

  const setProgress = async (idx: number) => {
    setStepIndex(idx)
    externalSetStepIndex?.(idx)
    await api.updateCurrentStep(idx)
  }

  const resetProgress = async (swiperRef?: React.RefObject<any>) => {
    await api.resetProgress()
    setStepIndex(0)
    setInitialSlide(0)
    externalSetStepIndex?.(0)
    externalSetInitialSlide?.(0)
    swiperRef?.current?.slideTo?.(0, 0)
  }

  return { stepIndex, initialSlide, setProgress, resetProgress }
}
